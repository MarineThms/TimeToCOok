//
//  RatatouillePrototypeApp.swift
//  RatatouillePrototype
//
//  Created by Apprenant 17 on 09/03/2023.
//

import SwiftUI

@main
struct RatatouillePrototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ChargementView()
        }
    }
}
