//
//  ColorAsset.swift
//  RatatouillePrototype
//
//  Created by Apprenant 17 on 09/03/2023.
//

import SwiftUI

var GrayColor = Color("GrayColor")
var GrayDarkColor = Color("GrayDarkColor")
var GraySomberColor = Color("GraySomberColor")
var CouleurVert = Color("CouleurVert")
var CouleurNoir = Color("CouleurNoir")
var CouleurOrange = Color("CouleurOrange")
var CouleurJaune = Color("CouleurJaune")
var CouleurOrangeClaire = Color("CouleurOrangeClaire")

